// HARIA-WEB MVC managed controller
/*PROTECTED REGION ID(ComentarioController_usings) START*/
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using WikiGames.Domain.Entities;
using WikiGames.Application.Services;
using WikiGames.WebEjemplo.Assemblers;

using WikiGames.Domain.Enums;
/*PROTECTED REGION END*/

namespace WikiGames.WebEjemplo.Controllers;

/*PROTECTED REGION ID(ComentarioController_class_attributes) ENABLED START*/
[Authorize]
/*PROTECTED REGION END*/
public partial class ComentarioController : Controller
{
    /*PROTECTED REGION ID(ComentarioController_dependencies) START*/
    private readonly WikiGames.Application.Abstractions.IUnitOfWorkFactory _useCaseUnitOfWorkFactory;
    private readonly ComentarioService _comentarioService;
    private readonly ContenidoService _contenidoService;
    private readonly ILogger<ComentarioController> _logger;
    private readonly WikiGames.Application.Abstractions.IUnitOfWorkFactory _formUnitOfWorkFactory;
    public ComentarioController(ComentarioService comentarioService, ContenidoService contenidoService, WikiGames.Application.Abstractions.IUnitOfWorkFactory formUnitOfWorkFactory, WikiGames.Application.Abstractions.IUnitOfWorkFactory useCaseUnitOfWorkFactory, ILogger<ComentarioController>? logger = null)
    {
        _comentarioService = comentarioService;
        _contenidoService = contenidoService;

        _formUnitOfWorkFactory = formUnitOfWorkFactory;
        _useCaseUnitOfWorkFactory = useCaseUnitOfWorkFactory;
        _logger = logger ?? global::Microsoft.Extensions.Logging.Abstractions.NullLogger<ComentarioController>.Instance;
    }
    /*PROTECTED REGION END*/
    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_Index_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> Index()
    {
    /*PROTECTED REGION ID(ComentarioController_Index_GET_body) START*/

        var entities = await _comentarioService.ReadAllAsync();
        return View(entities.Select(ComentarioAssembler.ToViewModel).ToList());
    /*PROTECTED REGION END*/
    }

    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_Details_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> Details(int id)
    {
    /*PROTECTED REGION ID(ComentarioController_Details_GET_body) START*/

        var entity = await _comentarioService.ReadOIDAsync(id);
        if (entity is null) return NotFound();
        return View(ComentarioAssembler.ToViewModel(entity));
    /*PROTECTED REGION END*/
    }

    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_Create_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> Create()
    {
    /*PROTECTED REGION ID(ComentarioController_Create_GET_body) START*/

        var model = new WikiGames.WebEjemplo.ViewModels.ComentarioViewModel();

        await LoadFormOptionsAsync(model);
        return View(model);
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_Create_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> Create(WikiGames.WebEjemplo.ViewModels.ComentarioViewModel model)
    {
    /*PROTECTED REGION ID(ComentarioController_Create_POST_body) START*/


        await using var unitOfWork = _formUnitOfWorkFactory.Create();
        var service = new ComentarioService(unitOfWork);



        await LoadFormOptionsAsync(model, unitOfWork);
        if (model.TemaId is int selectedTema &&
            !model.TemaOptions.Any(option => option.Value == Convert.ToString(selectedTema, System.Globalization.CultureInfo.InvariantCulture)))
            ModelState.AddModelError("TemaId", "Selecciona un registro existente de TemaConversacion.");
        if (model.TemaId is null) ModelState.AddModelError("TemaId", "Debes seleccionar una opción.");
        if (model.ComentarioAsociadoId is int selectedComentarioAsociado &&
            !model.ComentarioAsociadoOptions.Any(option => option.Value == Convert.ToString(selectedComentarioAsociado, System.Globalization.CultureInfo.InvariantCulture)))
            ModelState.AddModelError("ComentarioAsociadoId", "Selecciona un registro existente de Comentario.");

        if (model.UsuarioCreadorId is int selectedUsuarioCreador &&
            !model.UsuarioCreadorOptions.Any(option => option.Value == Convert.ToString(selectedUsuarioCreador, System.Globalization.CultureInfo.InvariantCulture)))
            ModelState.AddModelError("UsuarioCreadorId", "Selecciona un registro existente de Usuario.");
        if (model.UsuarioCreadorId is null) ModelState.AddModelError("UsuarioCreadorId", "Debes seleccionar una opción.");


        if (!ModelState.IsValid) return View(model);

        await unitOfWork.BeginTransactionAsync("MVC.Comentario.Create");
        try
        {

            var entity = await service.NewAsync(model.Texto, model.FechaCreacion, model.NumeroMeGusta, model.TemaId.GetValueOrDefault(), model.UsuarioCreadorId.GetValueOrDefault());
            entity.Tema = model.TemaId is int referenceTema
                ? await unitOfWork.TemaConversacionRepository.ReadAsync(referenceTema) ?? throw new InvalidOperationException("El registro seleccionado de TemaConversacion ya no existe.") : null!;
            entity.ComentarioAsociado = model.ComentarioAsociadoId is int referenceComentarioAsociado
                ? await unitOfWork.ComentarioRepository.ReadAsync(referenceComentarioAsociado) ?? throw new InvalidOperationException("El registro seleccionado de Comentario ya no existe.") : null!;
            entity.UsuarioCreador = model.UsuarioCreadorId is int referenceUsuarioCreador
                ? await unitOfWork.UsuarioRepository.ReadAsync(referenceUsuarioCreador) ?? throw new InvalidOperationException("El registro seleccionado de Usuario ya no existe.") : null!;

            await service.ModifierComentarioDefaultAsync(entity);

            await unitOfWork.CommitAsync();
        }
        catch (Exception error)
        {
            await unitOfWork.RollbackAsync();
            if (error is OperationCanceledException) throw;
            _logger.LogError(error, "Could not save the record and its lines.");
            ModelState.AddModelError(string.Empty, "No se han podido guardar el registro y sus líneas.");
            return View(model);
        }

        return RedirectToAction(nameof(Index));
    /*PROTECTED REGION END*/
    }

    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_Edit_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> Edit(int id)
    {
    /*PROTECTED REGION ID(ComentarioController_Edit_GET_body) START*/

        var entity = await _comentarioService.ReadOIDAsync(id);
        if (entity is null) return NotFound();
        var model = ComentarioAssembler.ToViewModel(entity);
        await LoadFormOptionsAsync(model);
        return View(model);
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_Edit_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> Edit(int id, WikiGames.WebEjemplo.ViewModels.ComentarioViewModel model)
    {
    /*PROTECTED REGION ID(ComentarioController_Edit_POST_body) START*/


        await using var unitOfWork = _formUnitOfWorkFactory.Create();
        var service = new ComentarioService(unitOfWork);
        var entity = await service.ReadOIDComentarioDefaultAsync(id);
        if (entity is null) return NotFound();


        await LoadFormOptionsAsync(model, unitOfWork);
        if (model.TemaId is int selectedTema &&
            !model.TemaOptions.Any(option => option.Value == Convert.ToString(selectedTema, System.Globalization.CultureInfo.InvariantCulture)))
            ModelState.AddModelError("TemaId", "Selecciona un registro existente de TemaConversacion.");
        if (model.TemaId is null) ModelState.AddModelError("TemaId", "Debes seleccionar una opción.");
        if (model.ComentarioAsociadoId is int selectedComentarioAsociado &&
            !model.ComentarioAsociadoOptions.Any(option => option.Value == Convert.ToString(selectedComentarioAsociado, System.Globalization.CultureInfo.InvariantCulture)))
            ModelState.AddModelError("ComentarioAsociadoId", "Selecciona un registro existente de Comentario.");

        if (model.UsuarioCreadorId is int selectedUsuarioCreador &&
            !model.UsuarioCreadorOptions.Any(option => option.Value == Convert.ToString(selectedUsuarioCreador, System.Globalization.CultureInfo.InvariantCulture)))
            ModelState.AddModelError("UsuarioCreadorId", "Selecciona un registro existente de Usuario.");
        if (model.UsuarioCreadorId is null) ModelState.AddModelError("UsuarioCreadorId", "Debes seleccionar una opción.");


        if (!ModelState.IsValid) return View(model);

        await unitOfWork.BeginTransactionAsync("MVC.Comentario.Edit");
        try
        {

            await service.ModifyAsync(id, model.Texto, model.FechaCreacion, model.NumeroMeGusta, model.TemaId.GetValueOrDefault(), model.UsuarioCreadorId.GetValueOrDefault());
            entity.Tema = model.TemaId is int referenceTema
                ? await unitOfWork.TemaConversacionRepository.ReadAsync(referenceTema) ?? throw new InvalidOperationException("El registro seleccionado de TemaConversacion ya no existe.") : null!;
            entity.ComentarioAsociado = model.ComentarioAsociadoId is int referenceComentarioAsociado
                ? await unitOfWork.ComentarioRepository.ReadAsync(referenceComentarioAsociado) ?? throw new InvalidOperationException("El registro seleccionado de Comentario ya no existe.") : null!;
            entity.UsuarioCreador = model.UsuarioCreadorId is int referenceUsuarioCreador
                ? await unitOfWork.UsuarioRepository.ReadAsync(referenceUsuarioCreador) ?? throw new InvalidOperationException("El registro seleccionado de Usuario ya no existe.") : null!;

            await service.ModifierComentarioDefaultAsync(entity);

            await unitOfWork.CommitAsync();
        }
        catch (Exception error)
        {
            await unitOfWork.RollbackAsync();
            if (error is OperationCanceledException) throw;
            _logger.LogError(error, "Could not save the record and its lines.");
            ModelState.AddModelError(string.Empty, "No se han podido guardar el registro y sus líneas.");
            return View(model);
        }

        return RedirectToAction(nameof(Index));
    /*PROTECTED REGION END*/
    }

    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_Delete_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> Delete(int id)
    {
    /*PROTECTED REGION ID(ComentarioController_Delete_GET_body) START*/

        var entity = await _comentarioService.ReadOIDAsync(id);
        if (entity is null) return NotFound();
        return View(ComentarioAssembler.ToViewModel(entity));
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ActionName("Delete")]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_DeleteConfirmed_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
    /*PROTECTED REGION ID(ComentarioController_DeleteConfirmed_POST_body) START*/

        if (!ModelState.IsValid) return View("Delete", new WikiGames.WebEjemplo.ViewModels.ComentarioViewModel());
        await _comentarioService.DestroyAsync(id);
        return RedirectToAction(nameof(Index));
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_AddComentarioAsociado_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> AddComentarioAsociado(int p_oid, int p_comentario2_oid)
    {
    /*PROTECTED REGION ID(ComentarioController_AddComentarioAsociado_POST_body) START*/

        if (!ModelState.IsValid) return BadRequest(ModelState);
        await _comentarioService.AddComentarioAsociadoAsync(p_oid, p_comentario2_oid);
        return NoContent();
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_AddRespuesta_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> AddRespuesta(int p_oid, IReadOnlyList<int> p_comentario2_oids)
    {
    /*PROTECTED REGION ID(ComentarioController_AddRespuesta_POST_body) START*/

        if (!ModelState.IsValid) return BadRequest(ModelState);
        await _comentarioService.AddRespuestaAsync(p_oid, p_comentario2_oids);
        return NoContent();
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_AddDenuncia_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> AddDenuncia(int p_oid, IReadOnlyList<int> p_denuncia_oids)
    {
    /*PROTECTED REGION ID(ComentarioController_AddDenuncia_POST_body) START*/

        if (!ModelState.IsValid) return BadRequest(ModelState);
        await _contenidoService.AddDenunciaAsync(p_oid, p_denuncia_oids);
        return NoContent();
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_AddUsuarioFavorito_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> AddUsuarioFavorito(int p_oid, IReadOnlyList<int> p_usuario_oids)
    {
    /*PROTECTED REGION ID(ComentarioController_AddUsuarioFavorito_POST_body) START*/

        if (!ModelState.IsValid) return BadRequest(ModelState);
        await _contenidoService.AddUsuarioFavoritoAsync(p_oid, p_usuario_oids);
        return NoContent();
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_AddUsuarioMeGusta_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> AddUsuarioMeGusta(int p_oid, IReadOnlyList<int> p_usuario_oids)
    {
    /*PROTECTED REGION ID(ComentarioController_AddUsuarioMeGusta_POST_body) START*/

        if (!ModelState.IsValid) return BadRequest(ModelState);
        await _contenidoService.AddUsuarioMeGustaAsync(p_oid, p_usuario_oids);
        return NoContent();
    /*PROTECTED REGION END*/
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    /*PROTECTED REGION ID(ComentarioController_QuitarUsuarioMeGusta_POST_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> QuitarUsuarioMeGusta(int p_oid, IReadOnlyList<int> p_usuario_oids)
    {
    /*PROTECTED REGION ID(ComentarioController_QuitarUsuarioMeGusta_POST_body) START*/

        if (!ModelState.IsValid) return BadRequest(ModelState);
        await _contenidoService.QuitarUsuarioMeGustaAsync(p_oid, p_usuario_oids);
        return NoContent();
    /*PROTECTED REGION END*/
    }

    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_FindByTextoLinQ_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> FindByTextoLinQ(string p_texto)
    {
    /*PROTECTED REGION ID(ComentarioController_FindByTextoLinQ_GET_body) START*/

        var result = await _contenidoService.FindByTextoLinQAsync(p_texto);
        return Ok(result.Select(ContenidoAssembler.ToViewModel).ToList());
    /*PROTECTED REGION END*/
    }

    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_FindOrderByFecha_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> FindOrderByFecha()
    {
    /*PROTECTED REGION ID(ComentarioController_FindOrderByFecha_GET_body) START*/

        var result = await _contenidoService.FindOrderByFechaAsync();
        return Ok(result.Select(ContenidoAssembler.ToViewModel).ToList());
    /*PROTECTED REGION END*/
    }

    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_FindOrderMeGusta_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> FindOrderMeGusta()
    {
    /*PROTECTED REGION ID(ComentarioController_FindOrderMeGusta_GET_body) START*/

        var result = await _contenidoService.FindOrderMeGustaAsync();
        return Ok(result.Select(ContenidoAssembler.ToViewModel).ToList());
    /*PROTECTED REGION END*/
    }

    [HttpGet]
    /*PROTECTED REGION ID(ComentarioController_FindBYUserLiked_GET_attributes) START*/
    /*PROTECTED REGION END*/
    public async Task<IActionResult> FindBYUserLiked(int p_user)
    {
    /*PROTECTED REGION ID(ComentarioController_FindBYUserLiked_GET_body) START*/

        var result = await _contenidoService.FindBYUserLikedAsync(p_user);
        return Ok(result.Select(ContenidoAssembler.ToViewModel).ToList());
    /*PROTECTED REGION END*/
    }

    /*PROTECTED REGION ID(ComentarioController_method_LoadFormOptionsAsync_WikiGamesWebEjemploViewModelsComentarioViewModel) START*/
    private async Task LoadFormOptionsAsync(WikiGames.WebEjemplo.ViewModels.ComentarioViewModel model)
    {
        await using var unitOfWork = _formUnitOfWorkFactory.Create();
        await LoadFormOptionsAsync(model, unitOfWork);
    }
    /*PROTECTED REGION END*/

    /*PROTECTED REGION ID(ComentarioController_method_LoadFormOptionsAsync_WikiGamesWebEjemploViewModelsComentarioViewModel_WikiGamesApplicationAbstractionsIUnitOfWork) START*/
    private async Task LoadFormOptionsAsync(WikiGames.WebEjemplo.ViewModels.ComentarioViewModel model, WikiGames.Application.Abstractions.IUnitOfWork unitOfWork)
    {

        var options0 = (await unitOfWork.TemaConversacionRepository.ReadAllAsync()).Select(item => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem { Value = Convert.ToString(item.Id, System.Globalization.CultureInfo.InvariantCulture), Text = Convert.ToString(item.Titulo, System.Globalization.CultureInfo.InvariantCulture) ?? string.Empty }).ToList();
        var options1 = (await unitOfWork.ComentarioRepository.ReadAllAsync()).Select(item => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem { Value = Convert.ToString(item.Id, System.Globalization.CultureInfo.InvariantCulture), Text = Convert.ToString(item.Texto, System.Globalization.CultureInfo.InvariantCulture) ?? string.Empty }).ToList();
        var options2 = (await unitOfWork.UsuarioRepository.ReadAllAsync()).Select(item => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem { Value = Convert.ToString(item.Id, System.Globalization.CultureInfo.InvariantCulture), Text = Convert.ToString(item.Name, System.Globalization.CultureInfo.InvariantCulture) ?? string.Empty }).ToList();
        model.TemaOptions = options0.Select(item => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
        {
            Value = item.Value,
            Text = item.Text
        }).ToList();
        model.ComentarioAsociadoOptions = options1.Select(item => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
        {
            Value = item.Value,
            Text = item.Text
        }).ToList();
        model.UsuarioCreadorOptions = options2.Select(item => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
        {
            Value = item.Value,
            Text = item.Text
        }).ToList();

    }
    /*PROTECTED REGION END*/

}
